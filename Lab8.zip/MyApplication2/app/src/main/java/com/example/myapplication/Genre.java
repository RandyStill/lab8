package com.example.myapplication;

import java.util.ArrayList;

public class Genre {

    public void music(String[] args){
        ArrayList<String> titlesMu = new ArrayList<String>(10);
        titlesMu.add("K-On!");
        titlesMu.add("Shigatsu wa Kimi no Uso");
        titlesMu.add("Love Live! Sunshine!!");
        titlesMu.add("Zombieland Saga");
        titlesMu.add("SoniAni: Super Sonico The Animation");
        titlesMu.add("Show By Rock!! Mashumairesh!!");
        titlesMu.add("Hibike! Euphonium");
        titlesMu.add("The iDOLM@STER");
        titlesMu.add("Sakamichi no Apollon");
        titlesMu.add("Shelter");
    }

    public void romance(String[] args){
        ArrayList<String> titlesR = new ArrayList<String>(10);
        titlesR.add("Toradora!");
        titlesR.add("sankarea");
        titlesR.add("My Little Monster");
        titlesR.add("Your Lie in April");
        titlesR.add("The Kawai Complex Guide to Manors and Hostel Behavior");
        titlesR.add("From Me to You");
        titlesR.add("Golden Times");
        titlesR.add("Blue Spring Ride");
        titlesR.add("The Pet Girl of Sakurasou");
        titlesR.add("My Love Story!!");
    }

    public void action(String[] args){
        ArrayList<String> titlesA = new ArrayList<String>(10);
        titlesA.add("Ansatsu Kyoushitsu");
        titlesA.add("Dragon Ball Z");
        titlesA.add("FLCL(Fooly Cooly)");
        titlesA.add("Black Lagoon");
        titlesA.add("Deadman Wonderland");
        titlesA.add("Sword Art Online");
        titlesA.add("Accel World");
        titlesA.add("Shingeki no Kyojin");
        titlesA.add("Tokyo Ghoul");
        titlesA.add("Naruto");
    }

    public void schoolLife(String[] args){
        ArrayList<String> titlesSL = new ArrayList<String>(10);
        titlesSL.add("Chuunibyou demo Koi ga Shitai!");
        titlesSL.add("Rosario to Vampire");
        titlesSL.add("Kami nomi zo Shiru Sekai");
        titlesSL.add("Demi-chan wa Kataritai");
        titlesSL.add("Ben-to");
        titlesSL.add("Boku no Hero Academia");
        titlesSL.add("Shokugeki no Souma: Ni no Sara");
        titlesSL.add("Kakegurui");
        titlesSL.add("Absolute Duo");
        titlesSL.add("Karakai Jouzu no Takagi-san");
    }

    public void horror(String[] args){
        ArrayList<String> titlesH = new ArrayList<String>(10);
        titlesH.add("Higurashi");
        titlesH.add("Parasyte");
        titlesH.add("Another");
        titlesH.add("Yamishibai");
        titlesH.add("Boogiepop Phantom");
        titlesH.add("Shiki");
        titlesH.add("Paranoia Agent");
        titlesH.add("Blood+");
        titlesH.add("Ghost Hunt");
        titlesH.add("Death Note");
    }

    public void drama(String[] args){
        ArrayList<String> titlesD = new ArrayList<String>(10);
        titlesD.add("A Silent Voice");
        titlesD.add("ERASED");
        titlesD.add("Anohana: The Flower We Saw That Day");
        titlesD.add("Grave Of The Fireflies");
        titlesD.add("Orange");
        titlesD.add("Fruits Basket");
        titlesD.add("March Comes In Like A Lion");
        titlesD.add("A Lull in the Sea");
        titlesD.add("Welcome To The NHK!");
        titlesD.add("Rorouni Kenshin: Trust & Betrayal");
    }

    public void mystery(String[] args){
        ArrayList<String> titlesMy = new ArrayList<String>(10);
        titlesMy.add("The Promised Neverland");
        titlesMy.add("Bungo Stray Dogs");
        titlesMy.add("Durarara!!");
        titlesMy.add("Detective Conan");
        titlesMy.add("Made In Abyss");
        titlesMy.add("Mushishi");
        titlesMy.add("Baccano!");
        titlesMy.add("Beatiful Bones -Sakurako's Investigation");
        titlesMy.add("Un-Go");
        titlesMy.add("Higurashi no Naku Koro ni");
    }

    public void sciFi(String[] args){
        ArrayList<String> titlesSF = new ArrayList<String>(10);
        titlesSF.add("Cowboy Bebop");
        titlesSF.add("Code Geass: Hangyaku no Lelouch");
        titlesSF.add("Neon Genesis Evangelion");
        titlesSF.add("Darling in the FranXX");
        titlesSF.add("Ghost in the Shell");
        titlesSF.add("Black Bullet");
        titlesSF.add("Tengen Toppa Gurren Lagann");
        titlesSF.add("Btooom!");
        titlesSF.add("Trigun");
        titlesSF.add("Infinite Stratos");
    }
}
